# lambda/get_nlb_enis.py
import boto3
import json
import urllib3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def send_response(event, context, response_status, response_data):
    response_url = event['ResponseURL']

    response_body = {
        'Status': response_status,
        'Reason': f'See CloudWatch Logs - {context.log_stream_name}',
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': False,
        'Data': response_data
    }

    json_response_body = json.dumps(response_body)

    logger.info(f"Sending response to {response_url}: {json_response_body}")

    headers = {
        'content-type': 'application/json',
        'content-length': str(len(json_response_body))
    }

    http = urllib3.PoolManager()
    try:
        response = http.request('PUT', response_url,
                              headers=headers,
                              body=json_response_body)
        logger.info(f"CloudFormation returned status code: {response.status}")
    except Exception as e:
        logger.error(f"Failed to send response to CloudFormation: {str(e)}")

def handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        if event['RequestType'] in ['Create', 'Update']:
            ec2 = boto3.client('ec2')
            response = ec2.describe_network_interfaces(
                Filters=[{
                    'Name': 'description',
                    'Values': ['ELB net/*']
                }]
            )
            
            eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
            logger.info(f"Found ENIs: {eni_ids}")
            
            response_data = {
                'ENIs': ','.join(eni_ids) if eni_ids else 'none'
            }
            
            logger.info(f"Sending response data: {response_data}")
            send_response(event, context, 'SUCCESS', response_data)
            return response_data  # Add return statement
        else:
            # For Delete requests
            response_data = {'ENIs': 'none'}
            send_response(event, context, 'SUCCESS', response_data)
            return response_data  # Add return statement
            
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        response_data = {'ENIs': 'none'}
        send_response(event, context, 'FAILED', response_data)
        return response_data  # Add return statement
