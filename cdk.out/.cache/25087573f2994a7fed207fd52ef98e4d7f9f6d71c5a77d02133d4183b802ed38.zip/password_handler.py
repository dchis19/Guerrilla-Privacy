import boto3
import json
import os
import logging
import base64
import rsa

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def decrypt_password(encrypted_password, private_key_pem):
    try:
        # Decode the base64 encrypted password
        encrypted_password_bytes = base64.b64decode(encrypted_password)
        
        # Load the private key
        private_key = rsa.PrivateKey.load_pkcs1(private_key_pem.encode('utf-8'))
        
        # Decrypt the password
        decrypted_password = rsa.decrypt(encrypted_password_bytes, private_key)
        
        return decrypted_password.decode('utf-8')
    except Exception as e:
        logger.error(f"Error decrypting password: {str(e)}")
        raise e

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    if 'detail-type' in event:
        return handle_instance_launch(event)
    else:
        logger.error("Unexpected event type received")
        raise Exception("Invalid event type")

def handle_instance_launch(event):
    try:
        ec2 = boto3.client('ec2')
        ssm = boto3.client('ssm')
        autoscaling = boto3.client('autoscaling')
        
        detail = event.get('detail', {})
        instance_id = detail.get('EC2InstanceId')
        
        if not instance_id:
            logger.error("No EC2 instance ID found in event")
            return
            
        logger.info(f"Processing instance: {instance_id}")
        
        # Get the private key from SSM Parameter Store
        key_pair_parameter_name = os.environ['KEY_PAIR_PARAMETER_NAME']
        private_key_pem = ssm.get_parameter(
            Name=key_pair_parameter_name,
            WithDecryption=True
        )['Parameter']['Value']
        
        logger.info("Retrieved private key from SSM")
        
        # Wait for password data to be available
        logger.info(f"Waiting for password data for instance {instance_id}")
        waiter = ec2.get_waiter('password_data_available')
        waiter.wait(
            InstanceId=instance_id,
            WaiterConfig={'Delay': 15, 'MaxAttempts': 40}
        )
        
        # Get the encrypted password
        password_data = ec2.get_password_data(InstanceId=instance_id)
        encrypted_password = password_data['PasswordData']
        
        if encrypted_password:
            logger.info("Retrieved encrypted password, attempting to decrypt")
            
            try:
                # Decrypt the password
                decrypted_password = decrypt_password(encrypted_password, private_key_pem)
                
                logger.info("Successfully decrypted Windows password")
                
                # Store the decrypted password in Parameter Store
                ssm.put_parameter(
                    Name=f"/EC2/Passwords/{instance_id}",
                    Value=decrypted_password,
                    Type='SecureString',
                    Overwrite=True
                )
                
                logger.info(f"Successfully stored decrypted password for instance {instance_id}")
                
            except Exception as decrypt_error:
                logger.error(f"Failed to decrypt password: {str(decrypt_error)}")
                raise decrypt_error
            
            # Complete lifecycle action if this was triggered by a lifecycle hook
            if detail.get('LifecycleHookName'):
                logger.info("Completing lifecycle hook")
                autoscaling.complete_lifecycle_action(
                    LifecycleHookName=detail['LifecycleHookName'],
                    AutoScalingGroupName=detail['AutoScalingGroupName'],
                    InstanceId=instance_id,
                    LifecycleActionResult='CONTINUE'
                )
                logger.info("Lifecycle hook completed")
                
        return {
            'statusCode': 200,
            'body': json.dumps('Password processing completed successfully')
        }
        
    except Exception as e:
        logger.error(f"Error processing instance password: {str(e)}")
        raise e
