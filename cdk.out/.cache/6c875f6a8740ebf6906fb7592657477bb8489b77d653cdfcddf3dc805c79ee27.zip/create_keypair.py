import boto3
import json

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    ssm = boto3.client('ssm')
    
    request_type = event['RequestType']
    key_pair_name = event['ResourceProperties']['KeyPairName']
    # In create_keypair.py
    parameter_name = os.environ['PARAMETER_NAME']
    
    try:
        if request_type == 'Create':
            # Create the key pair and immediately capture the private key
            key_pair = ec2.create_key_pair(KeyName=key_pair_name)
            private_key = key_pair['KeyMaterial']
            
            # Store private key in Parameter Store
            ssm.put_parameter(
                Name=parameter_name,
                Value=private_key,
                Type='SecureString',
                Overwrite=True
            )
            
            return {
                'PhysicalResourceId': key_pair_name,
                'Data': {
                    'KeyName': key_pair_name
                }
            }
            
        elif request_type == 'Delete':
            # Delete the key pair
            try:
                ec2.delete_key_pair(KeyName=key_pair_name)
                ssm.delete_parameter(Name=parameter_name)
            except:
                pass
            
            return {
                'PhysicalResourceId': key_pair_name
            }
            
        elif request_type == 'Update':
            # For updates, create new key pair and delete old one
            old_key_name = event['PhysicalResourceId']
            
            # Delete old key pair
            try:
                ec2.delete_key_pair(KeyName=old_key_name)
            except:
                pass
                
            # Create new key pair
            key_pair = ec2.create_key_pair(KeyName=key_pair_name)
            private_key = key_pair['KeyMaterial']
            
            # Update parameter
            ssm.put_parameter(
                Name=parameter_name,
                Value=private_key,
                Type='SecureString',
                Overwrite=True
            )
            
            return {
                'PhysicalResourceId': key_pair_name,
                'Data': {
                    'KeyName': key_pair_name
                }
            }
            
    except Exception as e:
        print(e)
        raise e
