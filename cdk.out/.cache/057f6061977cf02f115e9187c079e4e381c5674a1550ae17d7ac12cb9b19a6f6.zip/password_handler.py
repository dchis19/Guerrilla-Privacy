# password_handler.py
import boto3
import json
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Check if this is an EventBridge event (ASG instance launch)
    if 'detail-type' in event:
        return handle_instance_launch(event)
    else:
        logger.error("Unexpected event type received")
        raise Exception("Invalid event type")

def handle_instance_launch(event):
    try:
        ec2 = boto3.client('ec2')
        ssm = boto3.client('ssm')
        autoscaling = boto3.client('autoscaling')
        
        detail = event.get('detail', {})
        instance_id = detail.get('EC2InstanceId')
        
        if not instance_id:
            logger.error("No EC2 instance ID found in event")
            return
            
        logger.info(f"Processing instance: {instance_id}")
        
        # Get the private key from SSM Parameter Store
        key_pair_parameter_name = os.environ['KEY_PAIR_PARAMETER_NAME']
        private_key = ssm.get_parameter(
            Name=key_pair_parameter_name,
            WithDecryption=True
        )['Parameter']['Value']
        
        # Wait for password data to be available
        waiter = ec2.get_waiter('password_data_available')
        waiter.wait(
            InstanceId=instance_id,
            WaiterConfig={'Delay': 15, 'MaxAttempts': 40}
        )
        
        # Get the encrypted password
        encrypted_password = ec2.get_password_data(InstanceId=instance_id)['PasswordData']
        
        if encrypted_password:
            # Store the password in Parameter Store
            ssm.put_parameter(
                Name=f"/EC2/Passwords/{instance_id}",
                Value=encrypted_password,
                Type='SecureString',
                Overwrite=True
            )
            
            logger.info(f"Successfully stored password for instance {instance_id}")
            
            # Complete lifecycle action if this was triggered by a lifecycle hook
            if detail.get('LifecycleHookName'):
                autoscaling.complete_lifecycle_action(
                    LifecycleHookName=detail['LifecycleHookName'],
                    AutoScalingGroupName=detail['AutoScalingGroupName'],
                    InstanceId=instance_id,
                    LifecycleActionResult='CONTINUE'
                )
                
        return {
            'statusCode': 200,
            'body': json.dumps('Password processing completed successfully')
        }
        
    except Exception as e:
        logger.error(f"Error processing instance password: {str(e)}")
        raise e
