# lambda/get_nlb_enis.py
import boto3
import json
import urllib3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Initialize response
    response_data = {
        'Data': {
            'ENIs': 'none'
        }
    }
    
    try:
        if event['RequestType'] in ['Create', 'Update']:
            ec2 = boto3.client('ec2')
            response = ec2.describe_network_interfaces(
                Filters=[{
                    'Name': 'description',
                    'Values': ['ELB net/*']
                }]
            )
            
            eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
            logger.info(f"Found ENIs: {eni_ids}")
            
            response_data = {
                'Data': {
                    'ENIs': ','.join(eni_ids) if eni_ids else 'none'
                }
            }
            
        return {
            'StatusCode': 200,
            'PhysicalResourceId': context.log_stream_name,
            **response_data
        }
            
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'StatusCode': 500,
            'PhysicalResourceId': context.log_stream_name,
            'Data': {
                'ENIs': 'none'
            }
        }
