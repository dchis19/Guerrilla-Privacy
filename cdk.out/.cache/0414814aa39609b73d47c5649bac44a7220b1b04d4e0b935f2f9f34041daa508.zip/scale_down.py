import boto3
import time
import json

def handler(event, context):
    print('Event:', json.dumps(event))
    
    # Only proceed for Create/Update events
    if event.get('RequestType') in ['Create', 'Update']:
        autoscaling = boto3.client('autoscaling')
        asg_name = event['ResourceProperties']['asgName']
        
        print('Waiting for 2 minutes to ensure instances are ready...')
        time.sleep(120)
        
        print('Scaling down to 0...')
        autoscaling.update_auto_scaling_group(
            AutoScalingGroupName=asg_name,
            MinSize=0,
            MaxSize=0,
            DesiredCapacity=0
        )
        
        print('Waiting 60 seconds for instances to terminate...')
        time.sleep(60)
        
        print('Scaling back up to 2...')
        autoscaling.update_auto_scaling_group(
            AutoScalingGroupName=asg_name,
            MinSize=2,
            MaxSize=2,
            DesiredCapacity=2
        )
    
    return {
        'PhysicalResourceId': 'ScaleDownComplete',
        'Status': 'SUCCESS'
    }
