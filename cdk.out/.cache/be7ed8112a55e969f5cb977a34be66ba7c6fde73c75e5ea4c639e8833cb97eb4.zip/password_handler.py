# password_handler.py
import boto3
import os
import json
import base64
import time
from botocore.exceptions import ClientError
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes

# Initialize AWS clients
ec2_client = boto3.client('ec2')
ssm_client = boto3.client('ssm')
kms_client = boto3.client('kms')

def wait_for_password(instance_id, max_attempts=30, delay=10):
    """Wait for the Windows password to become available"""
    for attempt in range(max_attempts):
        try:
            response = ec2_client.get_password_data(InstanceId=instance_id)
            if response['PasswordData']:
                return response['PasswordData']
        except ClientError as e:
            print(f"Attempt {attempt + 1}: Waiting for password data to become available")
        time.sleep(delay)
    raise Exception(f"Password data not available after {max_attempts * delay} seconds")

def get_instance_tags(instance_id):
    """Get instance tags in key-value format"""
    try:
        response = ec2_client.describe_instances(InstanceIds=[instance_id])
        tags = response['Reservations'][0]['Instances'][0].get('Tags', [])
        return {tag['Key']: tag['Value'] for tag in tags}
    except Exception as e:
        print(f"Error getting instance tags: {str(e)}")
        return {}

def lambda_handler(event, context):
    """Handle EC2 launch events and store Windows passwords securely"""
    print(f"Processing event: {json.dumps(event, indent=2)}")
    
    try:
        # Extract instance and ASG information
        instance_id = event['detail']['EC2InstanceId']
        asg_name = event['detail']['AutoScalingGroupName']
        
        # Get instance details to find the key name
        instance = ec2_client.describe_instances(InstanceIds=[instance_id])['Reservations'][0]['Instances'][0]
        key_name = instance['KeyName']
        instance_tags = get_instance_tags(instance_id)
        
        print(f"Processing instance {instance_id} from ASG {asg_name}")
        
        # Wait for password data to become available
        print(f"Waiting for password data for instance {instance_id}")
        password_data = wait_for_password(instance_id)
        
        # Get parameter prefix from environment
        parameter_prefix = os.environ['PARAMETER_PREFIX']
        
        # Get the private key from Parameter Store
        private_key_param_name = f"{parameter_prefix}/{key_name}"
        print(f"Retrieving private key from parameter: {private_key_param_name}")
        
        try:
            private_key_pem = ssm_client.get_parameter(
                Name=private_key_param_name,
                WithDecryption=True
            )['Parameter']['Value']
        except ClientError as e:
            print(f"Error retrieving private key: {str(e)}")
            raise Exception(f"Failed to retrieve private key from Parameter Store: {str(e)}")
        
        # Decrypt the password
        try:
            private_key = serialization.load_pem_private_key(
                private_key_pem.encode(),
                password=None
            )
            decrypted_password = private_key.decrypt(
                base64.b64decode(password_data),
                padding.PKCS1v15()
            ).decode('utf-8')
        except Exception as e:
            print(f"Error decrypting password: {str(e)}")
            raise Exception(f"Failed to decrypt password: {str(e)}")
        
        # Create the parameter name and value for the instance password
        password_parameter_name = f"/EC2/{instance_id}"
        parameter_value = f"Administrator, {decrypted_password}"
        
        # Prepare tags for the parameter
        parameter_tags = [
            {'Key': 'AutoScalingGroup', 'Value': asg_name},
            {'Key': 'InstanceId', 'Value': instance_id},
            {'Key': 'Environment', 'Value': instance_tags.get('Environment', 'unknown')},
            {'Key': 'CreatedBy', 'Value': 'PasswordHandler'},
            {'Key': 'CreatedDate', 'Value': time.strftime('%Y-%m-%d')}
        ]
        
        # Store the password in Parameter Store as a SecureString
        try:
            print(f"Storing password in parameter: {password_parameter_name}")
            ssm_client.put_parameter(
                Name=password_parameter_name,
                Description=f"Windows password for instance {instance_id} in {asg_name}",
                Value=parameter_value,
                Type='SecureString',
                DataType='text/secure',
                Tags=parameter_tags,
                Overwrite=True
            )
            print(f"Successfully stored password for instance {instance_id}")
            
        except ClientError as e:
            print(f"Error storing password in Parameter Store: {str(e)}")
            raise Exception(f"Failed to store password in Parameter Store: {str(e)}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Password retrieved and stored successfully',
                'instanceId': instance_id,
                'parameterName': password_parameter_name,
                'asgName': asg_name
            })
        }
        
    except Exception as e:
        error_message = str(e)
        print(f"Error in lambda_handler: {error_message}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_message,
                'instanceId': instance_id if 'instance_id' in locals() else 'unknown',
                'eventType': event.get('detail-type', 'unknown')
            })
        }

