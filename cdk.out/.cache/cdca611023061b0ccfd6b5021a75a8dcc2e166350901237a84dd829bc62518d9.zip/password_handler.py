# password_handler.py
import boto3
import json
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract instance information from the event
        detail = event.get('detail', {})
        instance_id = detail.get('EC2InstanceId')
        
        if not instance_id:
            logger.error("No EC2 instance ID found in event")
            return
            
        logger.info(f"Processing instance: {instance_id}")
        
        # Your existing password handling code...
        
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        raise e
