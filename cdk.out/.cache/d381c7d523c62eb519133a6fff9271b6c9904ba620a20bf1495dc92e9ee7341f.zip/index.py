# lambda/sqs-processor/index.py
import json
import boto3
import os

def handler(event, context):
    ec2 = boto3.client('ec2')
    
    # Process SQS messages
    for record in event['Records']:
        try:
            # Get message body
            message = json.loads(record['body'])
            instance_id = message['instance_id']
            
            print(f"Processing termination for instance: {instance_id}")
            
            # Verify instance exists and is running
            response = ec2.describe_instances(
                InstanceIds=[instance_id]
            )
            
            if response['Reservations']:
                instance = response['Reservations'][0]['Instances'][0]
                
                # Verify instance is in the correct VPC
                if instance['VpcId'] == os.environ['VPC_ID']:
                    # Terminate the instance
                    ec2.terminate_instances(
                        InstanceIds=[instance_id]
                    )
                    print(f"Successfully initiated termination for instance {instance_id}")
                else:
                    print(f"Instance {instance_id} is not in the expected VPC")
            else:
                print(f"Instance {instance_id} not found")
            
        except Exception as e:
            print(f"Error processing termination: {str(e)}")
            # Optionally re-raise to retry the message
            raise

    return {
        'statusCode': 200,
        'body': 'Instance termination processed'
    }
