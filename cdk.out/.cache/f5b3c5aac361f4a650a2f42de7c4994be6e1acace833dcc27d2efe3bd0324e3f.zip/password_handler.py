# lambda/password_handler.py
import boto3
import os
import json
import time
from datetime import datetime

def wait_for_password(ec2_client, instance_id, max_attempts=30, delay=20):
    """Wait for the Windows password to become available"""
    for attempt in range(max_attempts):
        try:
            response = ec2_client.get_password_data(InstanceId=instance_id)
            if response['PasswordData']:
                return response['PasswordData']
        except Exception as e:
            print(f"Attempt {attempt + 1}: Waiting for password data: {str(e)}")
        time.sleep(delay)
    raise Exception(f"Password data not available after {max_attempts * delay} seconds")

def lambda_handler(event, context):
    # Initialize clients
    ssm = boto3.client('ssm')
    ec2 = boto3.client('ec2')
    # In password_handler.py
    password_parameter_name = os.environ['PARAMETER_NAME']
    key_pair_parameter_name = os.environ['KEY_PAIR_PARAMETER_NAME']
    
    key_name = "MyKeyPair"  # You can make this dynamic through event input
    
    try:
        # Create the key pair and immediately capture the KeyMaterial
        key_pair = ec2.create_key_pair(KeyName=key_name)
        private_key = key_pair['KeyMaterial']  # This captures the private key at creation
        
        # Immediately store the private key in Parameter Store
        ssm.put_parameter(
            Name=f'/ec2/keypairs/{key_name}',
            Value=private_key,
            Type='SecureString',
            Overwrite=True
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Key pair {key_name} created and stored in Parameter Store',
                'keyName': key_name
            })
        }
        
        
    except Exception as e:
        error_message = str(e)
        print(f"Error: {error_message}")
        # If this is a CustomResource event, we need to raise the error
        if 'RequestType' in event:
            raise
        # For EventBridge events, return an error response
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_message,
                'instanceId': instance_id if 'instance_id' in locals() else 'unknown'
            })
        }
