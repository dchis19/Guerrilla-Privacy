# lambda/get_nlb_enis.py
import boto3
import cfnresponse

def handler(event, context):
    try:
        if event['RequestType'] in ['Create', 'Update']:
            ec2 = boto3.client('ec2')
            response = ec2.describe_network_interfaces(
                Filters=[{
                    'Name': 'description',
                    'Values': ['ELB net/*']
                }]
            )
            eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {
                'ENIs': ','.join(eni_ids)
            })
        else:
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
    except Exception as e:
        print(e)
        cfnresponse.send(event, context, cfnresponse.FAILED, {})
