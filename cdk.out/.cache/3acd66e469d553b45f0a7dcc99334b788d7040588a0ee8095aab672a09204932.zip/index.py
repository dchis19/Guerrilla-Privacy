import json
import boto3
import os
from datetime import datetime

def handler(event, context):
    ec2 = boto3.client('ec2')
    elbv2 = boto3.client('elbv2')
    sns = boto3.client('sns')
    
    for log_event in event['logEvents']:
        # Parse VPC Flow Log entry
        fields = log_event['message'].split()
        if len(fields) < 13:
            continue
            
        # VPC Flow Log format: version account-id interface-id srcaddr dstaddr srcport dstport protocol packets bytes start end action log-status
        src_addr = fields[3]
        dst_addr = fields[4]
        dst_port = fields[6]
        action = fields[11]
        
        # Only process accepted connections to port 3389
        if dst_port != '3389' or action != 'ACCEPT':
            continue
        
        try:
            # Get instance information based on private IP
            response = ec2.describe_instances(
                Filters=[
                    {
                        'Name': 'private-ip-address',
                        'Values': [dst_addr]
                    },
                    {
                        'Name': 'vpc-id',
                        'Values': [os.environ['VPC_ID']]
                    }
                ]
            )
            
            # If we found a matching instance
            if response['Reservations'] and response['Reservations'][0]['Instances']:
                instance = response['Reservations'][0]['Instances'][0]
                instance_id = instance['InstanceId']
                
                connection_info = {
                    'timestamp': datetime.now().isoformat(),
                    'source_ip': src_addr,
                    'instance_id': instance_id,
                    'connection_type': 'RDP',
                    'nlb_dns': os.environ['NLB_DNS']
                }
                
                # Publish to SNS
                sns.publish(
                    TopicArn=os.environ['SNS_TOPIC_ARN'],
                    Subject='New RDP Connection Detected',
                    Message=json.dumps(connection_info, indent=2)
                )
                
                print(json.dumps(connection_info))
                
                return {
                    'statusCode': 200,
                    'body': json.dumps(connection_info)
                }
                
        except Exception as e:
            print(f"Error processing connection: {str(e)}")
            continue
    
    return {
        'statusCode': 404,
        'body': 'No matching RDP connection found'
    }
