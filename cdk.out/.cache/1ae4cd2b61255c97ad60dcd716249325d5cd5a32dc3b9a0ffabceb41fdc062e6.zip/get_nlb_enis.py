# lambda/get_nlb_enis.py
import boto3
import json
import urllib3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def send_response(event, context, response_status, response_data):
    response_body = {
        'Status': response_status,
        'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': response_data
    }

    logger.info('Response: %s', response_body)

    http = urllib3.PoolManager()
    
    try:
        response = http.request(
            'PUT',
            event['ResponseURL'],
            body=json.dumps(response_body).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        logger.info('Status code: %s', response.status)
    except Exception as e:
        logger.error('Error sending response: %s', str(e))
        raise

def handler(event, context):
    logger.info('Event: %s', event)
    
    try:
        if event['RequestType'] in ['Create', 'Update']:
            ec2 = boto3.client('ec2')
            response = ec2.describe_network_interfaces(
                Filters=[{
                    'Name': 'description',
                    'Values': ['ELB net/*']
                }]
            )
            eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
            send_response(event, context, 'SUCCESS', {
                'ENIs': ','.join(eni_ids)
            })
        else:
            send_response(event, context, 'SUCCESS', {})
    except Exception as e:
        logger.error('Error: %s', str(e))
        send_response(event, context, 'FAILED', {})
