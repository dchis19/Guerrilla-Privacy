# lambda/password_handler.py
import boto3
import os
import json
import time
from datetime import datetime

def wait_for_password(ec2_client, instance_id, max_attempts=30, delay=20):
    """Wait for the Windows password to become available"""
    for attempt in range(max_attempts):
        try:
            response = ec2_client.get_password_data(InstanceId=instance_id)
            if response['PasswordData']:
                return response['PasswordData']
        except Exception as e:
            print(f"Attempt {attempt + 1}: Waiting for password data: {str(e)}")
        time.sleep(delay)
    raise Exception(f"Password data not available after {max_attempts * delay} seconds")

def lambda_handler(event, context):
    """Handle both CustomResource events and EventBridge events"""
    print(f"Received event: {json.dumps(event)}")
    
    # Initialize AWS clients
    ec2_client = boto3.client('ec2')
    ssm_client = boto3.client('ssm')
    
    try:
        # Check if this is a CustomResource event
        if 'RequestType' in event:
            if event['RequestType'] in ['Create', 'Update']:
                key_name = event['ResourceProperties']['KeyPairName']
                response = ec2_client.describe_key_pairs(
                    KeyNames=[key_name],
                    IncludePublicKey=False
                )
                key_material = response['KeyPairs'][0].get('KeyMaterial', '')
                return {
                    'PhysicalResourceId': key_name,
                    'Data': {
                        'KeyMaterial': key_material
                    }
                }
            return {
                'PhysicalResourceId': event.get('PhysicalResourceId', 'default')
            }
            
        # Handle EventBridge event for password retrieval
        instance_id = event['detail']['EC2InstanceId']
        asg_name = event['detail']['AutoScalingGroupName']
        
        # Get the password
        password_data = wait_for_password(ec2_client, instance_id)
        
        # Store in Parameter Store
        parameter_name = f"/EC2/{instance_id}"
        ssm_client.put_parameter(
            Name=parameter_name,
            Description=f"Windows password for instance {instance_id} in {asg_name}",
            Value=f"Administrator, {password_data}",
            Type='SecureString',
            KeyId=os.environ['KMS_KEY_ARN'],
            Overwrite=True,
            Tags=[
                {'Key': 'AutoScalingGroup', 'Value': asg_name},
                {'Key': 'InstanceId', 'Value': instance_id},
                {'Key': 'CreatedDate', 'Value': datetime.now().strftime('%Y-%m-%d')}
            ]
        )
        
        print(f"Successfully stored password for instance {instance_id}")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Password stored successfully',
                'instanceId': instance_id,
                'parameterName': parameter_name
            })
        }
        
    except Exception as e:
        error_message = str(e)
        print(f"Error: {error_message}")
        # If this is a CustomResource event, we need to raise the error
        if 'RequestType' in event:
            raise
        # For EventBridge events, return an error response
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': error_message,
                'instanceId': instance_id if 'instance_id' in locals() else 'unknown'
            })
        }
