import boto3
import pandas as pd
from datetime import datetime
from io import StringIO
import os
import json

s3_resource = boto3.resource("s3")
dynamodb_client = boto3.client("dynamodb")

def handler(event, context):
    try:
        # Calculate the date for today's report
        curr_date = datetime.now().strftime("%Y-%m-%d")

        response = dynamodb_client.query(
            TableName=os.environ.get("DDB_METADATA_TABLE"),
            IndexName="report-index",
            KeyConditionExpression="#date = :d",
            ExpressionAttributeNames={"#date": "current_date"},
            ExpressionAttributeValues={":d": {"S": curr_date}},
        )
        
        # Convert DynamoDB items to plain dictionaries
        data = []
        for item in response['Items']:
            cleaned_item = {}
            for key, value in item.items():
                # Extract the actual value from DynamoDB format
                cleaned_item[key] = list(value.values())[0]
            data.append(cleaned_item)

        # Create DataFrame from cleaned data
        df = pd.DataFrame(data)

        if df.empty:
            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                "body": json.dumps({
                    "message": f"No data found for {curr_date}"
                })
            }

        # Calculate status counts
        status_counts = df["task_status"].value_counts().to_dict()  # Convert to dict instead of series
        total_df = pd.DataFrame({
            "TotalFailed": [status_counts.get("FAILED", 0)],
            "TotalCompleted": [status_counts.get("COMPLETED", 0)]
        })

        combined_df = pd.concat([df, total_df], ignore_index=True)

        # Convert to CSV
        csv_buffer = StringIO()
        combined_df.to_csv(csv_buffer, index=False)

        # Write to S3
        filename = f"report_{datetime.now().isoformat()}.csv"
        s3_resource.Object(
            os.environ.get("REPORT_BUCKET"),
            filename
        ).put(Body=csv_buffer.getvalue())

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "message": f"Report for {curr_date} generated successfully",
                "filename": filename
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")  # Add logging
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "error": str(e)
            })
        }
