import json
import boto3
import os
from datetime import datetime
import base64
import zlib

def get_nlb_enis():
    try:
        ec2 = boto3.client('ec2')
        response = ec2.describe_network_interfaces(
            Filters=[{
                'Name': 'description',
                'Values': ['ELB net/*']
            }]
        )
        eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
        print(f"Found NLB ENIs: {eni_ids}")  # Debug logging
        return eni_ids
    except Exception as e:
        print(f"Error getting NLB ENIs: {str(e)}")
        return []

def handler(event, context):
    print(f"Received event: {json.dumps(event)}")  # Debug logging
    
    ec2 = boto3.client('ec2')
    elbv2 = boto3.client('elbv2')
    sns = boto3.client('sns')
    
    # Get NLB ENIs at the start
    nlb_enis = get_nlb_enis()
    
    try:
        # Handle CloudWatch Logs event format
        if 'awslogs' in event:
            # Decode and decompress the log data
            compressed_payload = base64.b64decode(event['awslogs']['data'])
            uncompressed_payload = zlib.decompress(compressed_payload, 16+zlib.MAX_WBITS)
            payload = json.loads(uncompressed_payload)
            log_events = payload['logEvents']
        else:
            log_events = event.get('logEvents', [])

        for log_event in log_events:
            try:
                print(f"Processing log event: {json.dumps(log_event)}")  # Debug logging
                
                # Parse VPC Flow Log entry
                message = log_event.get('message', '')
                fields = message.split()
                
                # Debug logging
                print(f"Fields parsed: {fields}")
                
                if len(fields) < 13:
                    print(f"Skipping log event - insufficient fields: {len(fields)}")
                    continue
                
                # Check if this is an NLB ENI
                interface_id = fields[2]
                if interface_id in nlb_enis:
                    print(f"Skipping NLB ENI: {interface_id}")
                    continue
                
                # VPC Flow Log format (default format):
                # version account-id interface-id srcaddr dstaddr srcport dstport protocol packets bytes start end action log-status
                src_addr = fields[3]
                dst_addr = fields[4]
                dst_port = fields[6]
                action = fields[11]
                
                print(f"Parsed values - src: {src_addr}, dst: {dst_addr}, port: {dst_port}, action: {action}")
                
                # Only process accepted connections to port 3389
                if dst_port != '3389' or action != 'ACCEPT':
                    print(f"Skipping - not an accepted RDP connection (port: {dst_port}, action: {action})")
                    continue
                
                # Get instance information based on private IP
                response = ec2.describe_instances(
                    Filters=[
                        {
                            'Name': 'private-ip-address',
                            'Values': [dst_addr]
                        },
                        {
                            'Name': 'vpc-id',
                            'Values': [os.environ['VPC_ID']]
                        }
                    ]
                )
                
                print(f"EC2 response: {json.dumps(response)}")  # Debug logging
                
                # If we found a matching instance
                if response['Reservations'] and response['Reservations'][0]['Instances']:
                    instance = response['Reservations'][0]['Instances'][0]
                    instance_id = instance['InstanceId']
                    
                    connection_info = {
                        'timestamp': datetime.now().isoformat(),
                        'source_ip': src_addr,
                        'destination_ip': dst_addr,
                        'instance_id': instance_id,
                        'interface_id': interface_id,  # Added interface_id
                        'connection_type': 'RDP',
                        'nlb_dns': os.environ.get('NLB_DNS', 'Not provided'),
                        'vpc_id': os.environ.get('VPC_ID', 'Not provided')
                    }
                    
                    # Publish to SNS
                    sns.publish(
                        TopicArn=os.environ['SNS_TOPIC_ARN'],
                        Subject='New RDP Connection Detected',
                        Message=json.dumps(connection_info, indent=2)
                    )
                    
                    print(f"Successfully published connection info: {json.dumps(connection_info)}")
                    
                    return {
                        'statusCode': 200,
                        'body': json.dumps(connection_info)
                    }
                else:
                    print(f"No matching instance found for IP: {dst_addr}")
                    
            except Exception as e:
                print(f"Error processing individual log event: {str(e)}")
                continue
        
        print("No matching RDP connections found in this batch")
        return {
            'statusCode': 404,
            'body': 'No matching RDP connection found'
        }
        
    except Exception as e:
        error_message = f"Error processing event: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'body': error_message
        }
