# lambda/get_nlb_enis.py
import boto3
import json
import urllib3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def send_response(event, context, response_status, response_data):
    response_body = {
        'Status': response_status,
        'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
        'PhysicalResourceId': context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': False,
        'Data': response_data  # This needs to match what we're looking for in the CDK
    }

    logger.info('Response body: %s', json.dumps(response_body))

    try:
        http = urllib3.PoolManager()
        response = http.request(
            'PUT',
            event['ResponseURL'],
            body=json.dumps(response_body).encode('utf-8'),
            headers={
                'Content-Type': 'application/json',
            }
        )
        logger.info('CloudFormation response status code: %s', response.status)
    except Exception as e:
        logger.error('Failed to send CloudFormation response: %s', str(e))
        raise

def handler(event, context):
    logger.info('Received event: %s', json.dumps(event))
    
    try:
        if event['RequestType'] in ['Create', 'Update']:
            ec2 = boto3.client('ec2')
            
            # Get NLB ENIs
            response = ec2.describe_network_interfaces(
                Filters=[{
                    'Name': 'description',
                    'Values': ['ELB net/*']
                }]
            )
            
            eni_ids = [eni['NetworkInterfaceId'] for eni in response['NetworkInterfaces']]
            logger.info('Found ENIs: %s', eni_ids)
            
            # Return the ENIs attribute specifically
            response_data = {
                'ENIs': ','.join(eni_ids) if eni_ids else 'none'  # Provide default value
            }
            
            send_response(event, context, 'SUCCESS', response_data)
        else:
            # For Delete requests, send empty success response
            send_response(event, context, 'SUCCESS', {'ENIs': 'none'})
            
    except Exception as e:
        logger.error('Error: %s', str(e))
        send_response(event, context, 'FAILED', {'ENIs': 'none'})

